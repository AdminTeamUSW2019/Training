﻿namespace WindowsFormsApp4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTestQuestions = new System.Windows.Forms.Label();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.lblSentence = new System.Windows.Forms.Label();
            this.rbtnAnswerDog = new System.Windows.Forms.RadioButton();
            this.rbtnAnswerBarked = new System.Windows.Forms.RadioButton();
            this.rbtnAnswerWalked = new System.Windows.Forms.RadioButton();
            this.btnNextQuestion = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTestQuestions
            // 
            this.lblTestQuestions.AutoSize = true;
            this.lblTestQuestions.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTestQuestions.Location = new System.Drawing.Point(12, 9);
            this.lblTestQuestions.Name = "lblTestQuestions";
            this.lblTestQuestions.Size = new System.Drawing.Size(176, 29);
            this.lblTestQuestions.TabIndex = 0;
            this.lblTestQuestions.Text = "Test Questions";
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblQuestion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(66, 96);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(376, 26);
            this.lblQuestion.TabIndex = 1;
            this.lblQuestion.Text = "What is the noun in the following sentence?";
            // 
            // lblSentence
            // 
            this.lblSentence.AutoSize = true;
            this.lblSentence.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSentence.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSentence.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSentence.Location = new System.Drawing.Point(66, 147);
            this.lblSentence.Name = "lblSentence";
            this.lblSentence.Size = new System.Drawing.Size(303, 27);
            this.lblSentence.TabIndex = 2;
            this.lblSentence.Text = "The dog barked as he walked.";
            // 
            // rbtnAnswerDog
            // 
            this.rbtnAnswerDog.AutoSize = true;
            this.rbtnAnswerDog.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAnswerDog.Location = new System.Drawing.Point(103, 239);
            this.rbtnAnswerDog.Name = "rbtnAnswerDog";
            this.rbtnAnswerDog.Size = new System.Drawing.Size(63, 28);
            this.rbtnAnswerDog.TabIndex = 3;
            this.rbtnAnswerDog.TabStop = true;
            this.rbtnAnswerDog.Text = "Dog";
            this.rbtnAnswerDog.UseVisualStyleBackColor = true;
            // 
            // rbtnAnswerBarked
            // 
            this.rbtnAnswerBarked.AutoSize = true;
            this.rbtnAnswerBarked.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAnswerBarked.Location = new System.Drawing.Point(103, 286);
            this.rbtnAnswerBarked.Name = "rbtnAnswerBarked";
            this.rbtnAnswerBarked.Size = new System.Drawing.Size(87, 28);
            this.rbtnAnswerBarked.TabIndex = 4;
            this.rbtnAnswerBarked.TabStop = true;
            this.rbtnAnswerBarked.Text = "Barked";
            this.rbtnAnswerBarked.UseVisualStyleBackColor = true;
            // 
            // rbtnAnswerWalked
            // 
            this.rbtnAnswerWalked.AutoSize = true;
            this.rbtnAnswerWalked.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAnswerWalked.Location = new System.Drawing.Point(103, 334);
            this.rbtnAnswerWalked.Name = "rbtnAnswerWalked";
            this.rbtnAnswerWalked.Size = new System.Drawing.Size(91, 28);
            this.rbtnAnswerWalked.TabIndex = 5;
            this.rbtnAnswerWalked.TabStop = true;
            this.rbtnAnswerWalked.Text = "Walked";
            this.rbtnAnswerWalked.UseVisualStyleBackColor = true;
            // 
            // btnNextQuestion
            // 
            this.btnNextQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextQuestion.Location = new System.Drawing.Point(570, 387);
            this.btnNextQuestion.Name = "btnNextQuestion";
            this.btnNextQuestion.Size = new System.Drawing.Size(218, 51);
            this.btnNextQuestion.TabIndex = 6;
            this.btnNextQuestion.Text = "Next Question";
            this.btnNextQuestion.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNextQuestion);
            this.Controls.Add(this.rbtnAnswerWalked);
            this.Controls.Add(this.rbtnAnswerBarked);
            this.Controls.Add(this.rbtnAnswerDog);
            this.Controls.Add(this.lblSentence);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.lblTestQuestions);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTestQuestions;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Label lblSentence;
        private System.Windows.Forms.RadioButton rbtnAnswerDog;
        private System.Windows.Forms.RadioButton rbtnAnswerBarked;
        private System.Windows.Forms.RadioButton rbtnAnswerWalked;
        private System.Windows.Forms.Button btnNextQuestion;
    }
}