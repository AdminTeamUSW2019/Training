﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text) || string.IsNullOrEmpty(txtQuantity.Text) || string.IsNullOrEmpty(txtCategory.Text))
            {
                return;
            }
            lstName.Items.Add(txtName.Text);
            lstQuantity.Items.Add(txtQuantity.Text);
            lstCategory.Items.Add(txtCategory.Text);
            txtName.Clear();
            txtQuantity.Clear();
            txtCategory.Clear();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult keypressed;
            keypressed = MessageBox.Show("You are about to delete an asset, are you sure you want to do this?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (keypressed == DialogResult.Yes)
            {
                if (lstName.SelectedItems.Count > 0)
                {
                    int index = lstName.Items.IndexOf(lstName.SelectedItem);
                    lstName.Items.RemoveAt(lstName.SelectedIndex);
                    lstQuantity.Items.RemoveAt(index);
                    lstCategory.Items.RemoveAt(index);


                }
                else if (lstQuantity.SelectedItems.Count > 0)
                {
                    int index = lstQuantity.Items.IndexOf(lstQuantity.SelectedItem);
                    lstQuantity.Items.RemoveAt(lstQuantity.SelectedIndex);
                    lstName.Items.RemoveAt(index);
                    lstCategory.Items.RemoveAt(index);


                }
                else if (lstCategory.SelectedItems.Count > 0)
                {
                    int index = lstCategory.Items.IndexOf(lstCategory.SelectedItem);
                    lstCategory.Items.RemoveAt(lstCategory.SelectedIndex);
                    lstName.Items.RemoveAt(index);
                    lstQuantity.Items.RemoveAt(index);
                }
            }
            else if(keypressed == DialogResult.No)
            {

            }
        }

        private void txtQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char chr = e.KeyChar;
            if (!Char.IsDigit(chr) && chr != 8)
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid number");
            }
        }
    }
}
