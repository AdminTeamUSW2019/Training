﻿namespace WindowsFormsApp4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTestQuestions = new System.Windows.Forms.Label();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.lblSentence = new System.Windows.Forms.Label();
            this.rbtnAnswerDog = new System.Windows.Forms.RadioButton();
            this.rbtnAnswerBarked = new System.Windows.Forms.RadioButton();
            this.rbtnAnswerWalked = new System.Windows.Forms.RadioButton();
            this.btnNextQuestion = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTestQuestions
            // 
            this.lblTestQuestions.AutoSize = true;
            this.lblTestQuestions.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTestQuestions.Location = new System.Drawing.Point(16, 11);
            this.lblTestQuestions.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTestQuestions.Name = "lblTestQuestions";
            this.lblTestQuestions.Size = new System.Drawing.Size(214, 36);
            this.lblTestQuestions.TabIndex = 0;
            this.lblTestQuestions.Text = "Test Questions";
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblQuestion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(88, 118);
            this.lblQuestion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(474, 31);
            this.lblQuestion.TabIndex = 1;
            this.lblQuestion.Text = "What is the noun in the following sentence?";
            // 
            // lblSentence
            // 
            this.lblSentence.AutoSize = true;
            this.lblSentence.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSentence.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSentence.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSentence.Location = new System.Drawing.Point(88, 181);
            this.lblSentence.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSentence.Name = "lblSentence";
            this.lblSentence.Size = new System.Drawing.Size(378, 33);
            this.lblSentence.TabIndex = 2;
            this.lblSentence.Text = "The dog barked as he walked.";
            // 
            // rbtnAnswerDog
            // 
            this.rbtnAnswerDog.AutoSize = true;
            this.rbtnAnswerDog.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAnswerDog.Location = new System.Drawing.Point(137, 294);
            this.rbtnAnswerDog.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnAnswerDog.Name = "rbtnAnswerDog";
            this.rbtnAnswerDog.Size = new System.Drawing.Size(79, 33);
            this.rbtnAnswerDog.TabIndex = 3;
            this.rbtnAnswerDog.TabStop = true;
            this.rbtnAnswerDog.Text = "Dog";
            this.rbtnAnswerDog.UseVisualStyleBackColor = true;
            this.rbtnAnswerDog.CheckedChanged += new System.EventHandler(this.rbtnAnswerDog_CheckedChanged);
            // 
            // rbtnAnswerBarked
            // 
            this.rbtnAnswerBarked.AutoSize = true;
            this.rbtnAnswerBarked.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAnswerBarked.Location = new System.Drawing.Point(137, 352);
            this.rbtnAnswerBarked.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnAnswerBarked.Name = "rbtnAnswerBarked";
            this.rbtnAnswerBarked.Size = new System.Drawing.Size(111, 33);
            this.rbtnAnswerBarked.TabIndex = 4;
            this.rbtnAnswerBarked.TabStop = true;
            this.rbtnAnswerBarked.Text = "Barked";
            this.rbtnAnswerBarked.UseVisualStyleBackColor = true;
            // 
            // rbtnAnswerWalked
            // 
            this.rbtnAnswerWalked.AutoSize = true;
            this.rbtnAnswerWalked.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAnswerWalked.Location = new System.Drawing.Point(137, 411);
            this.rbtnAnswerWalked.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnAnswerWalked.Name = "rbtnAnswerWalked";
            this.rbtnAnswerWalked.Size = new System.Drawing.Size(115, 33);
            this.rbtnAnswerWalked.TabIndex = 5;
            this.rbtnAnswerWalked.TabStop = true;
            this.rbtnAnswerWalked.Text = "Walked";
            this.rbtnAnswerWalked.UseVisualStyleBackColor = true;
            // 
            // btnNextQuestion
            // 
            this.btnNextQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextQuestion.Location = new System.Drawing.Point(760, 476);
            this.btnNextQuestion.Margin = new System.Windows.Forms.Padding(4);
            this.btnNextQuestion.Name = "btnNextQuestion";
            this.btnNextQuestion.Size = new System.Drawing.Size(291, 63);
            this.btnNextQuestion.TabIndex = 6;
            this.btnNextQuestion.Text = "Next Question";
            this.btnNextQuestion.UseVisualStyleBackColor = true;
            this.btnNextQuestion.Click += new System.EventHandler(this.btnNextQuestion_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnNextQuestion);
            this.Controls.Add(this.rbtnAnswerWalked);
            this.Controls.Add(this.rbtnAnswerBarked);
            this.Controls.Add(this.rbtnAnswerDog);
            this.Controls.Add(this.lblSentence);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.lblTestQuestions);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTestQuestions;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Label lblSentence;
        private System.Windows.Forms.RadioButton rbtnAnswerDog;
        private System.Windows.Forms.RadioButton rbtnAnswerBarked;
        private System.Windows.Forms.RadioButton rbtnAnswerWalked;
        private System.Windows.Forms.Button btnNextQuestion;
    }
}