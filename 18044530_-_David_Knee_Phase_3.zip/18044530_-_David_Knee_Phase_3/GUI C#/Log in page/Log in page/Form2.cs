﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Log_in_page
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnTraining_Click(object sender, EventArgs e)
        {
           

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            

            if (MessageBox.Show("Are you sure you want to log out? ", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("Logging out...");
                Form1 form1 = new Form1();
                form1.ShowDialog();

            }
        }
    }
}
