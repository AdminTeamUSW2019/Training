﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Log_in_page
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            txtPassword.PasswordChar = '*';
        }

        int attempts = 1;
        private void btnLog_Click(object sender, EventArgs e)
        {
            string username, password;
            username = txtUser.Text;
            password = txtPassword.Text;
            if (username == "Admin" && password == "Admin")
            {
                MessageBox.Show("Logging in...");
                Form2 form2 = new Form2();
                form2.ShowDialog();

            }

            else
            {
                MessageBox.Show("Incorrect details, please try again \nAttempts done: " + attempts + "out of 3");
                attempts++;
            }

           

            if(attempts == 4)
            {
                MessageBox.Show("You have reached the maximum number of attempts to log in.... Closing program");
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtUser.Clear();
            txtPassword.Clear();
        }
    }
}